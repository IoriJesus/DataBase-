REM B)
REM Write a SELECT statement that displays distinct course costs. 
REM In a separate column,show the COST increased by 75% and round 
REM the decimals to the nearest dollar. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');