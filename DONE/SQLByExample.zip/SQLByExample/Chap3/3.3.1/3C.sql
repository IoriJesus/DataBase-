REM C)
REM Write the query to accomplish the following output using the 
REM NVL2 function in the column 'Get this result'. 

COURSE_NO COST NEW
-------------- ------- ------
 430 1195 1075.5
 450 900
2 rows selected.

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');