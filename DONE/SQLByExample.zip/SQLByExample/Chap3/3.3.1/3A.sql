REM A)List the last name, first name, and phone number of students 
REM who do not have a phone number. Display '212-555-1212' for the phone number. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');