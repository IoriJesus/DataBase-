REM B)
REM Using functions in the SELECT list, WHERE, and ORDER BY clauses, 
REM write the SELECT statement that returns course numbers and course 
REM descriptions from the COURSE table and looks like the following result set:

Description
-------------------------------------
204.......Intro to SQL
130.......Intro to Unix
230.......Intro to Internet
20........Intro to Computers
25........Intro to Programming
120.......Intro to Java Programming
240.......Intro to the Basic Language
7 rows selected.

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');