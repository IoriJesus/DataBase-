REM E)
REM What do you observe when you execute the next statement? 
REM How would you change
REM the statement to achieve the desired result? 

SELECT TRIM('01' FROM '01230145601')
 FROM dual;

 dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');