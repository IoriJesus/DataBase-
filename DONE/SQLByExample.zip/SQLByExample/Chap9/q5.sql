spool C:\Users\Marlene\Desktop\BaseDatos\Capitulo9_Complex_Joins.txt

REM FULL OUTER JOIN
REM ANSI FULL OUTER JOIN

SELECT col1
   FROM t1;
spool off