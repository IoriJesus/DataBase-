spool C:\Users\Marlene\Desktop\BaseDatos\Capitulo9_Complex_Joins.txt

REM FULL OUTER JOIN
REM ANSI FULL OUTER JOIN


 SELECT col2
   FROM t2;
spool off