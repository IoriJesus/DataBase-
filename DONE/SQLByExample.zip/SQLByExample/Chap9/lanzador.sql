
clear screen
set linesize 130
set pagesize 100
spool log.txt
connect sergio/sergio
prompt starting scripts execution
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q1.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q2.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q3.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q4.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q5.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q6.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q7.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q8.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q9.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q10.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q11.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q12.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q13.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap9/q14.sql

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia')
pause end of execution
