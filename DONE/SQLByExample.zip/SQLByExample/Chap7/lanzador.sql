
clear screen
set linesize 130
set pagesize 100
spool log.txt
connect sergio/sergio
prompt starting scripts execution
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q1.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q2.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q3.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q4.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q5.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q6.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q7.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q8.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q9.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q10.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q11.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q12.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q13.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q14.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q15.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q16.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q17.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q18.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q19.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q20.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q21.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q22.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q23.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q24.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q25.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q26.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q27.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q28.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q29.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q30.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q31.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q32.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q33.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q34.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q35.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q36.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q37.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q38.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q39.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q40.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q41.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q42.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q43.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q44.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q45.sql
@@/root/Database-/Ejercicios/SQLByExample/Chap7/q46.sql

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia')
pause end of execution
