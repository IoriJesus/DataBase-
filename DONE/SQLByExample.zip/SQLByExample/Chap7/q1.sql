spool C:\Users\Marlene\Desktop\BaseDatos\Capitulo7_Subqueries.txt

REM Subqueries
REM Simple Subqueries
REM Scalar Subqueries

SELECT MIN(cost)
   FROM course;
spool off