spool C:\Users\Marlene\Desktop\BaseDatos\Capitulo8_Set_Operators.txt

REM Chapter 8.Set Operators
REM The MINUS And INTERSECT SET Operators
REM The MINUS Operator
SELECT instructor_id
   FROM instructor;
spool off