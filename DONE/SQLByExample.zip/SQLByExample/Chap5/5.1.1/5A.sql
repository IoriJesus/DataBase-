REM A)
REM Write a SELECT statement to determine how many courses 
REM do not have a prerequisite. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');