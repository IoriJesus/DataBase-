REM B)
REM Write a SELECT statement to determine the total number of students 
REM enrolled. Count students only once, no matter how many courses they
REM are enrolled in. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');