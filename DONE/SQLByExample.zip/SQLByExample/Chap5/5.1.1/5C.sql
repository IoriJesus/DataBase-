REM C)
REM Determine the average cost for all courses. If the course cost 
REM contains a null value,substitute the value 0. 
dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');