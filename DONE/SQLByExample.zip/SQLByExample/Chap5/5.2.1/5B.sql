REM B)
REM Write a SELECT statement showing student IDs and the number of 
REM courses they are enrolled in. Show only those enrolled in more 
REM than two classes. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');