REM D)
REM Write the same SELECT statement as in the previous question except for 
REM courses with exactly two sections. Hint: Think about the relationship 
REM between the COURSE and SECTION tables, specifically how many times a 
REM course can be represented in the SECTION table. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');