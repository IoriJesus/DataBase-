REM A)
REM Show a list of prerequisites and count how many times each appears 
REM in the COURSE table. Order the result by the PREREQUISITE column.  

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');