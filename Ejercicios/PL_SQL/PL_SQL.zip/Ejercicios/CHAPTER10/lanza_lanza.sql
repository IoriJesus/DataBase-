@%ORA_SCRIPTS%\cap10lanzador.sql
