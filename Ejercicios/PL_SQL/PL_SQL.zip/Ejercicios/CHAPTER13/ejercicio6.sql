UPDATE course_cost
   SET cost = 2000
 WHERE course_no = 450;