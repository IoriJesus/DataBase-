CREATE VIEW course_cost 
AS
   SELECT course_no, description, cost
     FROM course;