REM C)
REM Write a SELECT statement that displays the average room capacity
REM for each course.Display the average expressed to the nearest whole 
REM number in another column. Use column aliases for each column selected. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');