REM D)
REM Write a SELECT statement to determine the date of 
REM the most recent enrollment. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');