REM B)
REM For course numbers 430 and greater, show the course cost. 
REM Add another column reflecting a discount of 10% off the cost and 
REM substitute any NULL values in the COST column with the number 1000. 
REM The result should look similar to the following output. 

COURSE_NO COST NEW
-------------- ------- ------
 430 1195 1075.5
 450 900
2 rows selected.

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');