REM G)
REM Write the SQL statement to retrieve those students 
REM that have a last name with the
REM lowercase letter 'o' occurring three or more times. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');