REM D)
REM Display all the distinct salutations used in the INSTRUCTOR table. 
REM Order them alphabetically except for female salutations, 
REM which should be listed first. Hint: Use the
REM DECODE function or CASE expression in the ORDER BY clause. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');