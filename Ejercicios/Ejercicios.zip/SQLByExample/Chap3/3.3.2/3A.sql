REM A)
REM Rewrite the query from Exercise 3.3.1 c) using the DECODE function
REM instead. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');