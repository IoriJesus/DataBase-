REM C)
REM Write a SELECT Write a SELECT statement that displays distinct 
REM numeric grades from the GRADE table and half those values 
REM expressed as a whole number in a separate column. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');