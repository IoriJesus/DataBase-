REM A)
REM Write a SELECT statement that returns each instructor's last name,
REM followed by a comma and a space, followed by the instructor's first name, 
REM all in a single column in theresult set. 

dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');
