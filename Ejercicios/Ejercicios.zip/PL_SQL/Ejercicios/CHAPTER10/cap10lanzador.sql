set serveroutput ON;
SET PAGESIZE 50;
SET LINESIZE 130;

PROMPT Ruta:C:\Users\SergioS\Desktop\CS\LIBRO_DOS\cap10lanzador.sql
PROMPT SE INVOCO EL BUSCADOR

@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER10\ejercicio16.sql 
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER10\ejercicio17.sql
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER10\ejercicio18.sql
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER\ejercicio19.sql 
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER\ejercicio20.sql

 
 
 dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');
 


