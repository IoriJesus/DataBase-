set serveroutput ON;
clear screen;


PROMPT Ruta:C:\Users\SergioS\Desktop\CS\LIBRO_DOS\cap8lanzador.sql
PROMPT SE INVOCO EL BUSCADOR

@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER8\ejercicio6.sql 
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER8\ejercicio7.sql
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER8\ejercicio8.sql
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER8\ejercicio9.sql 
@C:\Users\SergioS\Desktop\CS\LIBRO_DOS\CHAPTER8\ejercicio10.sql

 
 
 dbms_output.put_line('--Sergio Gabriel Sanchez Valencia');
 
 