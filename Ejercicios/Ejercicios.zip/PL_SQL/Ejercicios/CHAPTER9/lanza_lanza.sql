
@%ORA_SCRIPTS%\cap9lanzador.sql