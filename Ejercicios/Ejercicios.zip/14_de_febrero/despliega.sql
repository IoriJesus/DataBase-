connect HR/HR
PROMPT INVOCA LA EJECUCION DE LOS QUERIES
CLEAR SCREEN
PAUSE	A CONTINUACION EL QUERY UNO
@@/root/dbs/14_de_febrero/q1.sql
PAUSE QUERY DOS
@@/root/dbs/14_de_febrero/q2.sql
PAUSE QUERY TES
@@/root/dbs/14_de_febrero/q3.sql
PAUSE QUERY CUATRO
@@/root/dbs/14_de_febrero/q4.sql
PAUSE QUERY CINCO
@@/root/dbs/14_de_febrero/q5.sql
PAUSE QUERY SEIS
@@/root/dbs/14_de_febrero/q6.sql
PAUSE QUERY SIETE
@@/root/dbs/14_de_febrero/q7.sql
PAUSE QUERY OCHO
@@/root/dbs/14_de_febrero/q8.sql
PAUSE QUERY NUEVE
@@/root/dbs/14_de_febrero/q9.sql
